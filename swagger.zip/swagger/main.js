(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error('Cannot find module "' + req + '".');
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ""

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"container\">\n    <div style=\"text-align: right\">\n        <button nz-button nzType=\"primary\" (click)=\"importDataModalVisible=true\">导入</button>\n        <button nz-button nzType=\"primary\" (click)=\"download()\">下载</button>\n    </div>\n</div>\n<div nz-row style=\"margin-top:100px\">\n    <div nz-col nzSpan=\"6\"></div>\n    <div nz-col nzSpan=\"12\">\n        <nz-input-group nzSuffixIcon=\"anticon anticon-search\">\n\n            <input type=\"search\" nz-input placeholder=\"关键字\" [(ngModel)]=\"keywords\" (search)=\"searchByKeyword()\">\n\n        </nz-input-group>\n    </div>\n</div>\n\n<div class=\"text-center\" style=\"margin-top: 60px;\">\n\n    <nz-tag [nzColor]=\"'#108ee9'\" (click)=\"checkTypes();state=View.All\" [nzChecked]=\"state==View.All\" [nzMode]=\"'checkable'\">全部</nz-tag>\n    <nz-tag [nzColor]=\"'green'\" (click)=\"checkTypes(View.Enum);state=View.Enum\" [nzChecked]=\"state==View.Enum\" [nzMode]=\"'checkable'\">枚举</nz-tag>\n    <nz-tag [nzColor]=\"'green'\" (click)=\"checkTypes(View.Entity);state=View.Entity\" [nzChecked]=\"state==View.Entity\" [nzMode]=\"'checkable'\">实体</nz-tag>\n    <nz-tag [nzColor]=\"'green'\" (click)=\"checkTypes(View.Api);state=View.Api\" [nzChecked]=\"state==View.Api\" [nzMode]=\"'checkable'\">接口</nz-tag>\n    <nz-tag [nzColor]=\"'green'\" (click)=\"checkTypes(View.Service);state=View.Service\" [nzChecked]=\"state==View.Service\" [nzMode]=\"'checkable'\">服务</nz-tag>\n</div>\n\n<div class=\"container\" *ngIf=\"state==View.All||state==View.Enum\">\n    <h2 class=\"group-title\">枚举\n        <nz-badge [nzCount]=\"objectKeys(totalEnums).length\"></nz-badge>\n    </h2>\n    <nz-divider></nz-divider>\n    <div nz-row>\n        <div nz-col nzSpan=\"8\" (click)=\"logEnum(key,totalEnums[key])\" *ngFor=\"let key of (objectKeys(totalEnums)|keyword:keywords)\" class=\"name\">\n            <span class=\"symbol enum\"></span> {{key}}\n        </div>\n    </div>\n</div>\n<div class=\"container\">\n    <h2 class=\"group-title\">实体\n        <nz-badge [nzCount]=\"objectKeys(totalClass).length\"></nz-badge>\n    </h2>\n    <nz-divider></nz-divider>\n    <div nz-row>\n        <div nz-col nzSpan=\"8\" (click)=\"logModel(key,totalClass[key])\" *ngFor=\"let key of (objectKeys(totalClass)|keyword:keywords)\" class=\"name\">\n            <span class=\"symbol model\"></span> {{key}}\n        </div>\n    </div>\n</div>\n\n<div class=\"container\">\n    <div style=\"display: flex;justify-content: space-between;\">\n        <h2 class=\"group-title\">Api标签\n            <nz-badge [nzCount]=\"objectKeys(totalTags).length\"></nz-badge>\n        </h2>\n        <nz-switch [(ngModel)]=\"multiApi\" nzCheckedChildren=\"多选\" nzUnCheckedChildren=\"单选\"></nz-switch>\n    </div>\n    <nz-divider></nz-divider>\n    <div nz-row>\n        <nz-tag class=\"name text-center\" nz-tooltip [nzTitle]=\"totalTags[tag].description\" nz-col nzSpan=\"6\" (nzCheckedChange)=\"apiTagCheck(totalTags[tag])\" nzMode=\"checkable\" [nzChecked]=\"totalTags[tag].checked\" *ngFor=\"let tag of (objectKeys(totalTags)|keyword:keywords)\">{{totalTags[tag].name}}</nz-tag>\n    </div>\n\n\n</div>\n<div class=\"container\">\n    <nz-divider></nz-divider>\n    <div nz-row>\n        <h2 class=\"group-title\">Http接口\n            <nz-badge [nzCount]=\"(objectKeys(displayPathObject)|keyword:keywords).length\"></nz-badge>\n        </h2>\n        <div nz-col (click)=\"logApi(key,displayPathObject[key])\" nzSpan=\"6\" *ngFor=\"let key of (objectKeys(displayPathObject)|keyword:keywords)\" class=\"name\">\n            <ng-container *ngIf=\"displayPathObject[key].get\">\n                <span class=\"symbol get\"></span> {{key}}\n            </ng-container>\n            <ng-container *ngIf=\"displayPathObject[key].post\">\n                <span class=\"symbol post\"></span> {{key}}\n            </ng-container>\n\n        </div>\n    </div>\n</div>\n\n\n\n<ng-container *ngIf=\"selectedData\">\n    <nz-modal [(nzVisible)]=\"visible\" [nzWidth]=\"1000\" [nzTitle]=\"getModalTitle()\" (nzOnCancel)=\"visible=false;\" (nzOnOk)=\"visible=false\">\n        <ng-container [ngSwitch]=\"selectedData.type\">\n            <ng-container *ngSwitchCase=\"'enum'\">\n\n                <div nz-row>\n\n                    <code nz-col nzSpan=\"12\"> \n                            <h2>java</h2>\n                            <pre>\n{{javaAdapter.getEnumTemplate(selectedData.data.key,selectedData.data.value)}}\n                            </pre>\n                            </code>\n\n                    <code nz-col nzSpan=\"12\">\n                        <h2>typescript</h2>\n                        <pre>\n{{tsAdapter.getEnumTemplate(selectedData.data.key,selectedData.data.value)}}\n</pre>\n                    </code>\n\n                </div>\n            </ng-container>\n            <!-- model -->\n            <div *ngSwitchCase=\"'model'\">\n                <div nz-row>\n\n                    <code nz-col nzSpan=\"12\"> \n                                    <h2>java</h2>\n                                    <pre>\n{{javaAdapter.getModelTemplate(selectedData.data.key,selectedData.data.value)}}\n                                    </pre>\n                                    </code>\n\n                    <code nz-col nzSpan=\"12\">\n                                <h2>typescript</h2>\n                                <pre>\n{{tsAdapter.getModelTemplate(selectedData.data.key,selectedData.data.value)}}\n        </pre>\n                            </code>\n\n                </div>\n            </div>\n            <div *ngSwitchCase=\"'api'\">\n                <div>路径:{{selectedData.data.key}}</div>\n                <div>请求方法: <span *ngIf=\"selectedData.data.value.get\" class=\"symbol get\"></span>\n                    <span *ngIf=\"selectedData.data.value.post\" class=\"symbol post\"></span>\n\n                </div>\n                <ng-container *ngIf=\"getSelelectQueryParams().length>0\">\n                    query:\n                    <div *ngFor=\"let param of getSelelectQueryParams() \">\n                        {{param| json}}\n                    </div>\n                </ng-container>\n                <ng-container *ngIf=\"getSelelectBodyParams() .length>0\"></ng-container>\n                <div *ngFor=\"let param of getSelelectBodyParams() \">\n                    {{param| json}}\n                </div>\n            </div>\n            <div *ngSwitchCase=\"'controller'\">\n                controller\n            </div>\n            <p *ngSwitchDefault>\n                未知\n            </p>\n\n        </ng-container>\n    </nz-modal>\n</ng-container>\n\n\n\n<h4>待添加特性</h4>\n<nz-checkbox-group [(ngModel)]=\"checkOptionsOne\" (ngModelChange)=\"log(checkOptionsOne)\"></nz-checkbox-group>\n\n<nz-modal [nzVisible]=\"importDataModalVisible\" [nzTitle]=\"'导入数据'\" (nzOnOk)=\"importDataModalVisible=false;onEnter()\" (nzOnCancel)=\"importDataModalVisible=false\">\n\n    <input type=\"search\" nz-input placeholder=\"swagger url address\" [(ngModel)]=\"url\" (search)=\"onEnter()\">\n\n</nz-modal>"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/ng-zorro-antd/esm5/antd.js");
/* harmony import */ var _types_swagger_parser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./types/swagger-parser */ "./src/app/types/swagger-parser.ts");
/* harmony import */ var _types_typescript_adapter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./types/typescript-adapter */ "./src/app/types/typescript-adapter.ts");
/* harmony import */ var _types_java_adapter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./types/java-adapter */ "./src/app/types/java-adapter.ts");
/* harmony import */ var _service_zip_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./service/zip-service */ "./src/app/service/zip-service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};







var View;
(function (View) {
    View[View["All"] = 0] = "All";
    View[View["Enum"] = 1] = "Enum";
    View[View["Entity"] = 2] = "Entity";
    View[View["Api"] = 3] = "Api";
    View[View["Service"] = 4] = "Service";
})(View || (View = {}));
var AppComponent = /** @class */ (function () {
    function AppComponent(http, nzMsg, zip) {
        this.http = http;
        this.nzMsg = nzMsg;
        this.zip = zip;
        this.View = View;
        this.state = View.All;
        this.importDataModalVisible = false;
        this.downloadOptions = {
            enumDir: "/share_platform/enum/",
            entityDir: "/share_platform/entity/",
            apiDir: "/share_platform/api/"
        };
        this.keywords = "";
        this.checkOptionsOne = [
            { label: '编辑器,设计器与代码同步', value: 'Apple', checked: true },
            { label: '测试集成,分组多样性参数,数据库表集成测试(后端java,单表查询封装称jar)', value: 'Pear' },
            { label: '类图与uml 实体分析,xml', value: 'Orange' },
            { label: 'enum,api,model,service,工具,管道', value: 'Orange' },
            { label: '前端文档解析' },
        ];
        this.visible = false;
        this.objectKeys = Object.keys;
        this.url = "/assets/demo-swagger.json";
        this.opt = {
            enumTemplateUrl: "http://localhost:4200/assets/templates/typescript/enum.nunjucks",
            modelTemplateUrl: "/assets/templates/typescript/mode.nunjucks",
            apiTemplateUrl: "/assets/template/typescript/api.nunjucks"
        };
        this.title = 'app';
        this.multiApi = false;
        this.totalEnums = {};
        this.totalClass = {};
        this.totalApi = {};
        this.totalTags = [];
        this.listOfOption = [];
        this.listOfTagOptions = [];
        this.displayPathObject = {};
    }
    AppComponent.prototype.download = function () {
        var _this = this;
        var enumFiles = Object.keys(this.totalEnums).map(function (key) { return { path: _this.downloadOptions.enumDir + key + ".ts", content: _this.tsAdapter.getEnumTemplate(key, _this.totalEnums[key]) }; });
        var entityFiles = Object.keys(this.totalClass).map(function (key) {
            return {
                path: _this.downloadOptions.entityDir + key + ".ts",
                content: _this.tsAdapter.getImportModels(_this.totalClass[key])
                    + _this.tsAdapter.getImportEnum(key, _this.totalClass[key])
                    + _this.tsAdapter.getModelTemplate(key, _this.totalClass[key])
            };
        });
        var apiFiels = Object.keys(this.totalApi).map(function (key) { return { path: _this.downloadOptions.apiDir + key + ".ts", content: _this.tsAdapter.getApiTemplate(key, _this.totalApi[key]) }; });
        this.zip.downloadZip((_a = enumFiles.concat.apply(enumFiles, entityFiles)).concat.apply(_a, apiFiels));
        var _a;
    };
    AppComponent.prototype.getSelectParams = function () {
        return (this.selectedData.data.value.get || this.selectedData.data.value.post).parameters;
    };
    AppComponent.prototype.getSelelectQueryParams = function () {
        return this.getSelectParams().filter(function (param) { return param.in == 'query'; });
    };
    AppComponent.prototype.getSelelectBodyParams = function () {
        return this.getSelectParams().filter(function (param) { return param.in == 'body'; });
    };
    AppComponent.prototype.log = function (value) {
        console.log(value);
    };
    AppComponent.prototype.getModalTitle = function () {
        if (this.selectedData) {
            switch (this.selectedData.type) {
                case "enum":
                    return "枚举:" + this.selectedData.data.key;
                case "model":
                    return "实体:" + this.selectedData.data.key;
                case "api":
                    return (this.selectedData.data.value.get ? "<span class=\"symbol get\"></span>" : "<span class=\"symbol post\"></span>") + "接口:" + this.selectedData.data.key;
            }
        }
        else {
            return "unkown";
        }
    };
    AppComponent.prototype.searchByKeyword = function () {
        if (this.keywords) {
        }
        else {
            this.parseData();
        }
    };
    AppComponent.prototype.checkTypes = function (type) {
        if (type) {
            this.type = type;
        }
        else {
            this.type = null;
        }
    };
    AppComponent.prototype.logEnum = function (key, value) {
        this.visible = true;
        this.selectedData = { type: "enum", data: { key: key, value: value } };
        console.log(this.tsAdapter.getEnumTemplate(key, value));
        console.log(this.javaAdapter.getEnumTemplate(key, value));
    };
    AppComponent.prototype.logModel = function (key, value) {
        this.visible = true;
        this.selectedData = { type: "model", data: { key: key, value: value } };
        console.log(this.tsAdapter.getModelTemplate(key, value));
        console.log(this.javaAdapter.getModelTemplate(key, value));
    };
    AppComponent.prototype.logController = function (key, apiController) {
        this.visible = true;
        this.selectedData = { type: "controller", data: { key: key, apiController: apiController } };
    };
    AppComponent.prototype.logApi = function (key, value) {
        this.visible = true;
        this.selectedData = { type: "api", data: { key: key, value: value } };
        // console.log(this.tsAdapter.getModelTemplate(key, value));
        // console.log(this.javaAdapter.getModelTemplate(key, value));
    };
    AppComponent.prototype.ngOnInit = function () {
        // this.onEnter();
    };
    AppComponent.prototype.apiTagCheck = function (tag) {
        var _this = this;
        if (this.multiApi) {
            tag.checked = !tag.checked;
        }
        else {
            this.objectKeys(this.totalTags).forEach(function (key) { return _this.totalTags[key].checked = false; });
            tag.checked = true;
        }
        this.displayPathObject = this.filterApi();
    };
    AppComponent.prototype.filterApi = function () {
        var _this = this;
        var result = {};
        var tags = this.totalTags.filter(function (tag) { return tag.checked; });
        if (tags.length > 0) {
            this.objectKeys(this.totalApi).filter(function (api) {
                var prop = _this.totalApi[api].get || _this.totalApi[api].post;
                var exisit = prop.tags.some(function (tag) { return tags.some(function (t) { return t.name == tag; }); });
                console.log(tags, prop.tags, exisit);
                return exisit;
            }).forEach(function (api) { return result[api] = _this.totalApi[api]; });
        }
        else {
            this.objectKeys(this.totalApi).forEach(function (api) { return result[api] = _this.totalApi[api]; });
        }
        return result;
    };
    AppComponent.prototype.onEnter = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        this.keywords = "";
                        _a = this;
                        return [4 /*yield*/, this.http.get(this.url).toPromise().catch(function (e) { return _this.nzMsg.error("404资源不存在"); })];
                    case 1:
                        _a.swaggerJson = (_b.sent());
                        this.parseData();
                        return [2 /*return*/];
                }
            });
        });
    };
    AppComponent.prototype.parseData = function () {
        return __awaiter(this, void 0, void 0, function () {
            var parser;
            return __generator(this, function (_a) {
                if (this.swaggerJson) {
                    parser = new _types_swagger_parser__WEBPACK_IMPORTED_MODULE_3__["SwaggerParser"](this.swaggerJson);
                    this.tsAdapter = new _types_typescript_adapter__WEBPACK_IMPORTED_MODULE_4__["TypescriptTemplateAdapter"](this.swaggerJson, this.opt);
                    this.javaAdapter = new _types_java_adapter__WEBPACK_IMPORTED_MODULE_5__["JavaTemplateAdapter"](this.swaggerJson);
                    this.totalEnums = parser.getTotalEnums();
                    this.totalClass = parser.getTotalClass();
                    this.totalTags = parser.getApiTags();
                    console.log(this.totalTags);
                    this.totalApi = parser.getTotalApi();
                    this.displayPathObject = this.filterApi();
                }
                else {
                    this.nzMsg.error("404资源不存在");
                }
                console.log(this.swaggerJson);
                return [2 /*return*/];
            });
        });
    };
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        }),
        __metadata("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"],
            ng_zorro_antd__WEBPACK_IMPORTED_MODULE_2__["NzMessageService"],
            _service_zip_service__WEBPACK_IMPORTED_MODULE_6__["ZipService"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ng-zorro-antd */ "./node_modules/ng-zorro-antd/esm5/antd.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common/locales/zh */ "./node_modules/@angular/common/locales/zh.js");
/* harmony import */ var _angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _pipe_capitalize__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./pipe/capitalize */ "./src/app/pipe/capitalize.ts");
/* harmony import */ var _pipe_keyword__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./pipe/keyword */ "./src/app/pipe/keyword.ts");
/* harmony import */ var _service_zip_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./service/zip-service */ "./src/app/service/zip-service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};












Object(_angular_common__WEBPACK_IMPORTED_MODULE_7__["registerLocaleData"])(_angular_common_locales_zh__WEBPACK_IMPORTED_MODULE_8___default.a);
var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_2__["AppComponent"],
                _pipe_capitalize__WEBPACK_IMPORTED_MODULE_9__["CapitalizePipe"],
                _pipe_keyword__WEBPACK_IMPORTED_MODULE_10__["KeywordPipe"]
            ],
            imports: [
                _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClientModule"],
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_0__["BrowserModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__["BrowserAnimationsModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _angular_common_http__WEBPACK_IMPORTED_MODULE_5__["HttpClientModule"],
                ng_zorro_antd__WEBPACK_IMPORTED_MODULE_6__["NgZorroAntdModule"]
            ],
            providers: [{ provide: ng_zorro_antd__WEBPACK_IMPORTED_MODULE_6__["NZ_I18N"], useValue: ng_zorro_antd__WEBPACK_IMPORTED_MODULE_6__["zh_CN"] }, _pipe_capitalize__WEBPACK_IMPORTED_MODULE_9__["CapitalizePipe"], _service_zip_service__WEBPACK_IMPORTED_MODULE_11__["ZipService"]],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_2__["AppComponent"]],
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/pipe/capitalize.ts":
/*!************************************!*\
  !*** ./src/app/pipe/capitalize.ts ***!
  \************************************/
/*! exports provided: CapitalizePipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CapitalizePipe", function() { return CapitalizePipe; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

/*
 * Capitalize the first letter of the string
 * Takes a string as a value.
 * Usage:
 *  value | capitalizefirst
 * Example:
 *  // value.name = daniel
 *  {{ value.name | capitalizefirst  }}
 *  fromats to: Daniel
*/
var CapitalizePipe = /** @class */ (function () {
    function CapitalizePipe() {
    }
    CapitalizePipe.prototype.transform = function (value, args) {
        if (value === null)
            return 'Not assigned';
        return value.charAt(0).toUpperCase() + value.slice(1);
    };
    CapitalizePipe = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Pipe"])({
            name: 'capitalize'
        })
    ], CapitalizePipe);
    return CapitalizePipe;
}());



/***/ }),

/***/ "./src/app/pipe/keyword.ts":
/*!*********************************!*\
  !*** ./src/app/pipe/keyword.ts ***!
  \*********************************/
/*! exports provided: KeywordPipe */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "KeywordPipe", function() { return KeywordPipe; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

/*
 * Capitalize the first letter of the string
 * Takes a string as a value.
 * Usage:
 *  value | capitalizefirst
 * Example:
 *  // value.name = daniel
 *  {{ value.name | capitalizefirst  }}
 *  fromats to: Daniel
*/
var KeywordPipe = /** @class */ (function () {
    function KeywordPipe() {
    }
    KeywordPipe.prototype.transform = function (args, keyword) {
        if (!keyword)
            return args;
        else {
            console.log();
            return args.filter(function (key) { return new RegExp(keyword, 'gi').test(key); });
        }
    };
    KeywordPipe = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Pipe"])({
            name: 'keyword'
        })
    ], KeywordPipe);
    return KeywordPipe;
}());



/***/ }),

/***/ "./src/app/service/zip-service.ts":
/*!****************************************!*\
  !*** ./src/app/service/zip-service.ts ***!
  \****************************************/
/*! exports provided: ZipService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ZipService", function() { return ZipService; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};

var ZipService = /** @class */ (function () {
    function ZipService() {
    }
    ZipService.prototype.createZipWriter = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, new Promise(function (resolve) { return zip.createWriter(new zip.BlobWriter("application/zip"), function (zipWriter) { resolve(zipWriter); }); })];
            });
        });
    };
    // TEMPORARY = "TEMPORARY";
    // requestFileSystem = window['webkitRequestFileSystem'] || window['mozRequestFileSystem'] || window['requestFileSystem'];
    ZipService.prototype.downloadZip = function (files) {
        return __awaiter(this, void 0, void 0, function () {
            var zipWriter, _i, files_1, file;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.createZipWriter()];
                    case 1:
                        zipWriter = _a.sent();
                        _i = 0, files_1 = files;
                        _a.label = 2;
                    case 2:
                        if (!(_i < files_1.length)) return [3 /*break*/, 5];
                        file = files_1[_i];
                        return [4 /*yield*/, this.addFile(zipWriter, file)];
                    case 3:
                        _a.sent();
                        _a.label = 4;
                    case 4:
                        _i++;
                        return [3 /*break*/, 2];
                    case 5:
                        this.downloadData(zipWriter);
                        return [2 /*return*/];
                }
            });
        });
    };
    ZipService.prototype.addFile = function (zipWriter, file) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2 /*return*/, new Promise(function (resolve) { return zipWriter.add(file.path, new zip.TextReader(file.content), function () { return resolve(true); }); })];
            });
        });
    };
    ZipService.prototype.closeFile = function (zipWriter) {
        return new Promise(function (resolve) { return zipWriter.close(function (bolb) { return resolve(bolb); }); });
    };
    ZipService.prototype.downloadData = function (zipWriter) {
        zipWriter.close(function (blob) {
            var blobURL = URL.createObjectURL(blob);
            var clickEvent;
            var downloadButton = document.createElement("a");
            clickEvent = document.createEvent("MouseEvent");
            clickEvent.initMouseEvent("click", true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);
            downloadButton.href = blobURL;
            downloadButton.download = "demo.zip";
            downloadButton.dispatchEvent(clickEvent);
            // creationMethodInput.disabled = false;
            // fileList.innerHTML = "";
            event.preventDefault();
            return false;
            // zipWriter = null;
        });
    };
    ZipService = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"])()
    ], ZipService);
    return ZipService;
}());



/***/ }),

/***/ "./src/app/types/java-adapter.ts":
/*!***************************************!*\
  !*** ./src/app/types/java-adapter.ts ***!
  \***************************************/
/*! exports provided: JavaTemplateAdapter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JavaTemplateAdapter", function() { return JavaTemplateAdapter; });
/* harmony import */ var _swagger_parser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./swagger-parser */ "./src/app/types/swagger-parser.ts");

var JavaTemplateAdapter = /** @class */ (function () {
    function JavaTemplateAdapter(swaggerJson, swaggerParser) {
        this.swaggerJson = swaggerJson;
        this.swaggerParser = swaggerParser;
        if (!swaggerParser)
            this.swaggerParser = new _swagger_parser__WEBPACK_IMPORTED_MODULE_0__["SwaggerParser"](swaggerJson);
    }
    JavaTemplateAdapter.prototype.getEnumTemplate = function (key, enumValue) {
        console.log(enumValue);
        return "public  enum " + key + "  {\n        " + enumValue.enum.join(',\n        ') + " ;\n            }";
        ;
    };
    JavaTemplateAdapter.prototype.getModelTemplate = function (key, modelValue) {
        var _this = this;
        return "export class " + key + " {\n        " + Object.keys(modelValue.properties).map(function (key) { return key + ":" + _this.swaggerParser.getModelType(_this.swaggerParser.getType(key, modelValue.properties[key], key)); }).join('\n        ') + "\n        }";
    };
    JavaTemplateAdapter.prototype.getContollerTemplate = function (key, controller) {
        return "";
    };
    JavaTemplateAdapter.prototype.getApiTemplate = function (key, apiValue) {
        return "";
    };
    JavaTemplateAdapter.prototype.getImportEnum = function (modelName, model) {
        return "";
    };
    JavaTemplateAdapter.prototype.getImportModels = function (model) {
        return "";
    };
    return JavaTemplateAdapter;
}());



/***/ }),

/***/ "./src/app/types/swagger-parser.ts":
/*!*****************************************!*\
  !*** ./src/app/types/swagger-parser.ts ***!
  \*****************************************/
/*! exports provided: SwaggerParser */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SwaggerParser", function() { return SwaggerParser; });
/* harmony import */ var _swagger__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./swagger */ "./src/app/types/swagger.ts");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./util */ "./src/app/types/util.ts");


var SwaggerParser = /** @class */ (function () {
    function SwaggerParser(swaggerJson) {
        this.swaggerJson = swaggerJson;
        console.log(swaggerJson);
    }
    SwaggerParser.prototype.getTotalApi = function () {
        return this.swaggerJson.paths;
    };
    SwaggerParser.prototype.getApiTags = function () {
        return this.swaggerJson.tags;
    };
    SwaggerParser.prototype.getTotalClass = function () {
        return this.swaggerJson.definitions;
    };
    SwaggerParser.prototype.getTotalEnums = function () {
        var _this = this;
        var props = {};
        var enums = [];
        for (var key in this.swaggerJson.definitions) {
            var model = this.swaggerJson.definitions[key];
            for (var propKey in model.properties) {
                var prop = model.properties[propKey];
                if (prop.type == _swagger__WEBPACK_IMPORTED_MODULE_0__["ApiPropertyTypeEnum"].string && prop.enum != null) {
                    /** 统配 enum */
                    enums.push({ key: propKey, prop: prop, model: key });
                }
                else {
                    // console.log(`not`, prop);
                }
            }
        }
        enums.forEach(function (e) {
            if (e.prop) {
                /** 重复多次判断 */
                var samekeys_1 = enums.filter(function (eu) { return e.key == eu.key; });
                /**
                 * 此时有相同的属性名称
                 * 判断每个key 的enum是否与其他完全一致
                 */
                if (samekeys_1.length > 1) {
                    console.log("=======" + e.model + "=" + e.key + "========");
                    var isAllthesame_1 = true;
                    samekeys_1.forEach(function (onekey) {
                        samekeys_1.forEach(function (temkey) {
                            if (!_this.enumThemsame(onekey.prop.enum, temkey.prop.enum)) {
                                isAllthesame_1 = false;
                            }
                        });
                    });
                    if (isAllthesame_1) {
                        // console.log(`isallthesam `, e);
                        props[Object(_util__WEBPACK_IMPORTED_MODULE_1__["captilize"])(e.key) + "Enum"] = {
                            type: _swagger__WEBPACK_IMPORTED_MODULE_0__["ApiPropertyTypeEnum"].string,
                            enum: e.prop.enum,
                            description: e.prop.description
                        };
                    }
                    else {
                        props[Object(_util__WEBPACK_IMPORTED_MODULE_1__["captilize"])(e.model) + Object(_util__WEBPACK_IMPORTED_MODULE_1__["captilize"])(e.key) + "Enum"] = {
                            type: _swagger__WEBPACK_IMPORTED_MODULE_0__["ApiPropertyTypeEnum"].string,
                            enum: e.prop.enum,
                            description: e.prop.description
                        };
                    }
                }
                else {
                    // console.log(`--------${e.key}-------------`);
                    props[Object(_util__WEBPACK_IMPORTED_MODULE_1__["captilize"])(e.key) + "Enum"] = {
                        type: _swagger__WEBPACK_IMPORTED_MODULE_0__["ApiPropertyTypeEnum"].string,
                        enum: e.prop.enum,
                        description: e.prop.description
                    };
                }
            }
        });
        /**
         * 1. key 分组
         * 如果 key相同而且所有属性相同,保留一个enum  原名
         * 如果 key相同而不同model的enum值不同,则进行分不同组
         */
        console.log(Object.getOwnPropertyNames(props));
        return props;
    };
    SwaggerParser.prototype.enumThemsame = function (e1, e2) {
        return e1.every(function (str, i) { return str === e2[i]; }) && e2.length == e1.length;
    };
    SwaggerParser.prototype.getType = function (key, property, modelName) {
        // console.log(key, property); 
        if (property.type) {
            switch (property.type.toLowerCase()) {
                case "integer":
                    return "number";
                case "number":
                    return "number";
                case "string":
                    switch (property.format) {
                        case _swagger__WEBPACK_IMPORTED_MODULE_0__["ApiPropertyTypeEnum"].dateTime:
                            return "Date";
                        default:
                            if (!property.enum) {
                                return "string";
                            }
                            else {
                                var totalEnum = this.getTotalEnums();
                                /** 统配 enum */
                                var keys = Object.keys(totalEnum);
                                if (keys.indexOf(Object(_util__WEBPACK_IMPORTED_MODULE_1__["captilize"])(key) + "Enum") != -1) {
                                    // debugger
                                    console.log(key);
                                    return Object(_util__WEBPACK_IMPORTED_MODULE_1__["captilize"])(key) + "Enum";
                                }
                                if (keys.indexOf(Object(_util__WEBPACK_IMPORTED_MODULE_1__["captilize"])(modelName) + Object(_util__WEBPACK_IMPORTED_MODULE_1__["captilize"])(key) + "Enum") != -1) {
                                    return Object(_util__WEBPACK_IMPORTED_MODULE_1__["captilize"])(modelName) + Object(_util__WEBPACK_IMPORTED_MODULE_1__["captilize"])(key) + "Enum";
                                }
                                else {
                                    // console.log(`not`, prop);
                                }
                                /** count enum  */
                            }
                            return "string";
                    }
                case "object":
                    return "any";
                case "boolean":
                    return "boolean";
                case "array":
                    if (property.items) {
                        if (property.items.$ref) {
                            return property.items.$ref;
                        }
                        if (property.items.type) {
                            return property.items.type + " []";
                        }
                    }
                    else {
                        return "unkown";
                    }
                default:
                    if (property.$ref != null) {
                        return property.$ref;
                    }
                    else {
                        return "unkown";
                    }
            }
        }
        else {
            return property.$ref;
        }
    };
    SwaggerParser.prototype.getImports = function (model) {
        var keys = Object.getOwnPropertyNames(model.properties);
        var importModels = new Set();
        for (var key in model.properties) {
            var prop = model.properties[key];
            if (prop.$ref) {
                importModels.add(prop.$ref.replace("#/definitions/", ""));
            }
            if (prop.items) {
                if (prop.items.$ref) {
                    importModels.add(prop.items.$ref.replace("#/definitions/", ""));
                }
            }
        }
        var values = importModels.values();
        var models = [];
        // for (let value of values) {
        //     models.push(value);
        // }
        return models;
    };
    SwaggerParser.prototype.getImportEnum = function (modelName, model) {
        console.log("modelname;" + modelName);
        var str = [];
        var totalEnum = this.getTotalEnums();
        for (var propKey in model.properties) {
            var prop = model.properties[propKey];
            if (prop.type == _swagger__WEBPACK_IMPORTED_MODULE_0__["ApiPropertyTypeEnum"].string && prop.enum != null) {
                /** 统配 enum */
                var keys = Object.keys(totalEnum);
                if (keys.indexOf(Object(_util__WEBPACK_IMPORTED_MODULE_1__["captilize"])(propKey) + "Enum") != -1) {
                    str.push(Object(_util__WEBPACK_IMPORTED_MODULE_1__["captilize"])(propKey) + "Enum");
                }
                if (keys.indexOf(Object(_util__WEBPACK_IMPORTED_MODULE_1__["captilize"])(modelName) + Object(_util__WEBPACK_IMPORTED_MODULE_1__["captilize"])(propKey) + "Enum") != -1) {
                    str.push(Object(_util__WEBPACK_IMPORTED_MODULE_1__["captilize"])(modelName) + Object(_util__WEBPACK_IMPORTED_MODULE_1__["captilize"])(propKey) + "Enum");
                }
            }
            else {
                // console.log(`not`, prop);
            }
        }
        return str;
    };
    SwaggerParser.prototype.getModelType = function (key) {
        if (key && key.startsWith("#/definitions")) {
            var models = Object.getOwnPropertyNames(this.swaggerJson.definitions);
            if (models.find(function (model) { return model == key.replace("#/definitions/", ""); })) {
                return key.replace("#/definitions/", "");
            }
            else {
                return key;
            }
        }
        else {
            if (key.endsWith("Enum")) {
                return key;
            }
            else {
                return key;
            }
        }
    };
    return SwaggerParser;
}());



/***/ }),

/***/ "./src/app/types/swagger.ts":
/*!**********************************!*\
  !*** ./src/app/types/swagger.ts ***!
  \**********************************/
/*! exports provided: ApiPropertyFormatEnum, ApiPropertyTypeEnum */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApiPropertyFormatEnum", function() { return ApiPropertyFormatEnum; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApiPropertyTypeEnum", function() { return ApiPropertyTypeEnum; });
var ApiPropertyFormatEnum;
(function (ApiPropertyFormatEnum) {
    ApiPropertyFormatEnum["Int64"] = "int64";
})(ApiPropertyFormatEnum || (ApiPropertyFormatEnum = {}));
var ApiPropertyTypeEnum;
(function (ApiPropertyTypeEnum) {
    ApiPropertyTypeEnum["integer"] = "integer";
    ApiPropertyTypeEnum["dateTime"] = "date-time";
    ApiPropertyTypeEnum["array"] = "array";
    ApiPropertyTypeEnum["string"] = "string";
})(ApiPropertyTypeEnum || (ApiPropertyTypeEnum = {}));


/***/ }),

/***/ "./src/app/types/typescript-adapter.ts":
/*!*********************************************!*\
  !*** ./src/app/types/typescript-adapter.ts ***!
  \*********************************************/
/*! exports provided: TypescriptTemplateAdapter */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TypescriptTemplateAdapter", function() { return TypescriptTemplateAdapter; });
/* harmony import */ var _swagger__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./swagger */ "./src/app/types/swagger.ts");
/* harmony import */ var _swagger_parser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./swagger-parser */ "./src/app/types/swagger-parser.ts");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./util */ "./src/app/types/util.ts");



var TypescriptTemplateAdapter = /** @class */ (function () {
    function TypescriptTemplateAdapter(swaggerJson, opt, swaggerParser) {
        this.swaggerJson = swaggerJson;
        this.opt = opt;
        this.swaggerParser = swaggerParser;
        if (!swaggerParser)
            this.swaggerParser = new _swagger_parser__WEBPACK_IMPORTED_MODULE_1__["SwaggerParser"](swaggerJson);
    }
    TypescriptTemplateAdapter.prototype.getEnumTemplate = function (key, enumValue) {
        return "export  enum " + key + "  {\n        " + enumValue.enum.map(function (en) { return en + "=\"" + en + "\";"; }).join('\n      ') + "\n    }\n        ";
    };
    TypescriptTemplateAdapter.prototype.getModelTemplate = function (key, modelValue) {
        var _this = this;
        return "export class " + key + " {\n        " + Object.keys(modelValue.properties).map(function (key) { return key + ":" + _this.swaggerParser.getModelType(_this.swaggerParser.getType(modelValue.properties[key].type, modelValue.properties[key], key)); }).join('\n        ') + "\n        }";
    };
    TypescriptTemplateAdapter.prototype.getImportEnum = function (modelName, model) {
        console.log("modelname;" + modelName);
        var str = [];
        var totalEnum = this.swaggerParser.getTotalEnums();
        for (var propKey in model.properties) {
            var prop = model.properties[propKey];
            if (prop.type == _swagger__WEBPACK_IMPORTED_MODULE_0__["ApiPropertyTypeEnum"].string && prop.enum != null) {
                /** 统配 enum */
                var keys = Object.keys(totalEnum);
                if (keys.indexOf(Object(_util__WEBPACK_IMPORTED_MODULE_2__["captilize"])(propKey) + "Enum") != -1) {
                    str.push(Object(_util__WEBPACK_IMPORTED_MODULE_2__["captilize"])(propKey) + "Enum");
                }
                if (keys.indexOf(Object(_util__WEBPACK_IMPORTED_MODULE_2__["captilize"])(modelName) + Object(_util__WEBPACK_IMPORTED_MODULE_2__["captilize"])(propKey) + "Enum") != -1) {
                    str.push(Object(_util__WEBPACK_IMPORTED_MODULE_2__["captilize"])(modelName) + Object(_util__WEBPACK_IMPORTED_MODULE_2__["captilize"])(propKey) + "Enum");
                }
            }
            else {
                // console.log(`not`, prop);
            }
        }
        return str.map(function (enumName) { return "import {" + enumName + "} from \"../enum/" + enumName + "\";"; }).join("\n") + "\n";
    };
    TypescriptTemplateAdapter.prototype.getContollerTemplate = function (key, controller) {
        return "";
    };
    TypescriptTemplateAdapter.prototype.getApiTemplate = function (key, apiValue) {
        return "";
    };
    TypescriptTemplateAdapter.prototype.getImportModels = function (model) {
        var keys = Object.getOwnPropertyNames(model.properties);
        var importModels = [];
        for (var key in model.properties) {
            var prop = model.properties[key];
            if (prop.$ref) {
                var name_1 = prop.$ref.replace("#/definitions/", "");
                if (importModels.indexOf(name_1) == -1)
                    importModels.push(prop.$ref.replace("#/definitions/", ""));
            }
            else {
                if (prop.items) {
                    // debugger;
                    if (prop.items.$ref) {
                        var name_2 = prop.items.$ref.replace("#/definitions/", "");
                        if (importModels.indexOf(name_2) == -1)
                            importModels.push(name_2);
                    }
                }
            }
        }
        return importModels.map(function (modelName) { return "import {" + modelName + "} from \"../entity/" + modelName + "\";"; }).join('\n') + "\n";
    };
    return TypescriptTemplateAdapter;
}());



/***/ }),

/***/ "./src/app/types/util.ts":
/*!*******************************!*\
  !*** ./src/app/types/util.ts ***!
  \*******************************/
/*! exports provided: captilize */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "captilize", function() { return captilize; });
function captilize(key) {
    console.log(key);
    var keyArr = key.split("");
    keyArr[0] = keyArr[0].toLocaleUpperCase();
    return keyArr.join("");
}


/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /Users/yangjie/Documents/workspace/company/swagger/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map